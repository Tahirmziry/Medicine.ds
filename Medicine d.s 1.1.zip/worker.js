export class VisitorCounter {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
  }

  async fetch(request) {
    if (request.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }
    let body;
    try { body = await request.json(); } catch {
      return Response.json({ error: "Invalid JSON" }, { status: 400 });
    }
    const visitorId = String(body?.visitorId || "");
    if (!/^[a-zA-Z0-9-]{8,100}$/.test(visitorId)) {
      return Response.json({ error: "Invalid visitor ID" }, { status: 400 });
    }

    const result = await this.ctx.storage.transaction(async txn => {
      const key = `visitor:${visitorId}`;
      const exists = await txn.get(key);
      let total = Number(await txn.get("total") || 0);
      if (!exists) {
        await txn.put(key, Date.now());
        total += 1;
        await txn.put("total", total);
      }
      return total;
    });

    return Response.json({ total: result }, {
      headers: { "Cache-Control": "no-store" }
    });
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/api/visitor-count") {
      const id = env.VISITOR_COUNTER.idFromName("global-medicine-ds-counter");
      return env.VISITOR_COUNTER.get(id).fetch(request);
    }
    return env.ASSETS.fetch(request);
  }
};
