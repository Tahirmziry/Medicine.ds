MEDICINE D.S. - عدّاد الزوار لكل جهاز مرة واحدة

هذه النسخة تستخدم Cloudflare Worker + Durable Object لتسجيل كل معرّف متصفح مرة واحدة فقط.
مهم: "الجهاز" هنا يعني نفس المتصفح وبياناته المحلية. إذا مسح المستخدم بيانات Safari، أو استخدم متصفحاً آخر/التصفح الخاص، قد يُحسب مرة أخرى.

النشر:
1) ارفع هذا المشروع إلى GitHub.
2) من Cloudflare افتح Workers & Pages ثم Create application ثم Import a repository.
3) اختر المستودع. إعدادات البناء غير مطلوبة؛ ملف wrangler.jsonc يحدد الإعدادات.
4) انشر Worker. يجب أن يظهر Durable Object binding باسم VISITOR_COUNTER تلقائياً من ملف الإعدادات.
5) افتح رابط workers.dev واختبر عدّاد الزوار.

لا تستخدم صفحة Upload and deploy للملفات الثابتة وحدها لهذه النسخة؛ يجب نشر worker.js وإعداد Durable Object أيضاً.
